import express from "express";
import path from "path";
import crypto from "crypto";
import nodemailer from "nodemailer";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON parsing and body configuration
  app.use(express.json());

  // Private secret keys (backed up with fallback secure default)
  const JWT_SECRET = process.env.JWT_SECRET || "dlp_enterprise_private_shielder_code_random_2026";

  // In-memory User accounts database array
  // Preseeding user@example.com & admin@dataleaktracker.com
  const USERS_DB = new Map<string, {
    id: number;
    name: string;
    email: string;
    passwordHash: string; // SHA-256 secure hash
    verified: boolean;
    failedLoginAttempts: number;
    lockoutUntil: number | null;
    otpRequests: { timestamp: number }[];
    otpHash: string | null;
    otpPurpose: 'signup' | 'login_2fa' | 'forgot_password' | null;
    otpExpiry: number | null;
    otpAttempts: number;
  }>();

  // Helper: Secure Password/String SHA-256 hashing
  function hashString(str: string): string {
    return crypto.createHash("sha256").update(str + "_dlp_salt_key_guard_2026_!").digest("hex");
  }

  // Preseed Admin
  USERS_DB.set("admin@dataleaktracker.com", {
    id: 1,
    name: "Cyber Security Lead",
    email: "admin@dataleaktracker.com",
    passwordHash: hashString("password123"), // hashed
    verified: true,
    failedLoginAttempts: 0,
    lockoutUntil: null,
    otpRequests: [],
    otpHash: null,
    otpPurpose: null,
    otpExpiry: null,
    otpAttempts: 0
  });

  // Preseed Standard User
  USERS_DB.set("user@example.com", {
    id: 2,
    name: "Admin User",
    email: "user@example.com",
    passwordHash: hashString("password"), // hashed
    verified: true,
    failedLoginAttempts: 0,
    lockoutUntil: null,
    otpRequests: [],
    otpHash: null,
    otpPurpose: null,
    otpExpiry: null,
    otpAttempts: 0
  });

  // Developer local Mail Catcher in-memory array
  const mailCatcherLogs: Array<{
    id: string;
    to: string;
    subject: string;
    body: string;
    otp: string;
    timestamp: string;
  }> = [];

  // Helper: Password strength audit criteria
  function checkPasswordStrength(password: string): { isValid: boolean; score: number; feedback: string[] } {
    const feedback: string[] = [];
    let score = 0;

    if (password.length >= 8) {
      score += 1;
    } else {
      feedback.push("At least 8 characters");
    }

    if (/[A-Z]/.test(password)) {
      score += 1;
    } else {
      feedback.push("At least one uppercase letter (A-Z)");
    }

    if (/[a-z]/.test(password)) {
      score += 1;
    } else {
      feedback.push("At least one lowercase letter (a-z)");
    }

    if (/\d/.test(password)) {
      score += 1;
    } else {
      feedback.push("At least one numeric digit (0-9)");
    }

    if (/[#$@!%&*?()]/.test(password)) {
      score += 1;
    } else {
      feedback.push("At least one special symbol (#$@!%&*?())");
    }

    return {
      isValid: score === 5,
      score,
      feedback
    };
  }

  // Helper: Custom Secure JWT Token Generation
  function generateJWT(payload: object): string {
    const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
    const claims = Buffer.from(JSON.stringify({
      ...payload,
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24) // 24 hours exp
    })).toString("base64url");

    const hmac = crypto.createHmac("sha256", JWT_SECRET);
    hmac.update(`${header}.${claims}`);
    const signature = hmac.digest("base64url");

    return `${header}.${claims}.${signature}`;
  }

  // Helper: Custom Secure JWT Verification with expiry analysis
  function verifyJWT(token: string): any {
    try {
      const parts = token.split(".");
      if (parts.length !== 3) return null;
      const [header, claims, signature] = parts;

      const hmac = crypto.createHmac("sha256", JWT_SECRET);
      hmac.update(`${header}.${claims}`);
      const expectedSignature = hmac.digest("base64url");

      if (signature !== expectedSignature) {
        return null;
      }

      const decodedClaims = JSON.parse(Buffer.from(claims, "base64url").toString("utf8"));
      if (decodedClaims.exp && decodedClaims.exp < Math.floor(Date.now() / 1000)) {
        return null; // Expired
      }

      return decodedClaims;
    } catch {
      return null;
    }
  }

  // Helper: Deliver email OTP using Nodemailer & save in Developer Mailcatcher
  async function triggerOtpEmail(toEmail: string, otpCode: string, purposeText: string) {
    const subject = `[Data Leak Tracker] OTP Safety Code: ${otpCode}`;
    const bodyText = `
Hello Security Operator,

Your requested 6-digit session validation code is: ${otpCode}

Request context: ${purposeText}
Security Token Expiration: exactamente 5 minutes.

Safety system notice: This email was transmitted under enterprise security compliance guidelines. Never share this code with anyone.
    `.trim();

    const bodyHtml = `
      <div style="font-family: inherit; font-size: 14px; max-width: 480px; padding: 24px; border: 1px solid #BBDEFB; border-radius: 12px; background-color: #FFFFFF; margin: 20px auto;">
        <div style="background-color: #E3F2FD; padding: 16px; border-radius: 8px; text-align: center; margin-bottom: 20px;">
          <h2 style="color: #0D47A1; margin: 0; font-size: 18px; font-weight: bold; letter-spacing: 0.5px;">DATA LEAK TRACKER SECURITY</h2>
        </div>
        <p style="color: #374151; margin-bottom: 12px;">Hello Security Operator,</p>
        <p style="color: #4B5563; line-height: 1.5; margin-bottom: 18px;">A multi-factor verification process was triggered. Please enter the transaction authorization OTP key code to proceed:</p>
        
        <div style="background-color: #F8FAFC; border: 1.5px dashed #2196F3; padding: 16px; border-radius: 10px; text-align: center; margin: 24px 0;">
          <span style="font-family: monospace; font-size: 34px; font-weight: 800; color: #2196F3; letter-spacing: 5px;">${otpCode}</span>
        </div>

        <p style="color: #6B7280; font-size: 12px; margin-bottom: 4px;"><strong>MFA Context:</strong> ${purposeText}</p>
        <p style="color: #DC2626; font-size: 11px; font-weight: bold; margin-bottom: 16px;">Notice: This OTP is valid for exactly 5 minutes, after which it expires. It allows an absolute maximum of 5 verification attempts.</p>
        
        <hr style="border: 0; border-top: 1px solid #E5E7EB; margin: 20px 0;" />
        <span style="font-size: 10px; color: #9CA3AF; display: block; text-align: center; font-family: monospace;">DATA LEAK PORTAL v3.0.0-PRO COMPLIANCE SECURED</span>
      </div>
    `;

    // 1. Push into local sandbox virtual Mail Catcher feed
    mailCatcherLogs.unshift({
      id: `mail-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      to: toEmail,
      subject,
      body: bodyText,
      otp: otpCode,
      timestamp: new Date().toLocaleTimeString()
    });

    // Prune mailcatcher
    if (mailCatcherLogs.length > 30) {
      mailCatcherLogs.pop();
    }

    // 2. Deliver physically if custom SMTP environment variables are fully configured
    if (process.env.SMTP_HOST) {
      try {
        const transporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST,
          port: parseInt(process.env.SMTP_PORT || "587"),
          secure: process.env.SMTP_PORT === "465",
          auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
          },
          timeout: 4000 // Fails fast
        } as any);

        await transporter.sendMail({
          from: `"${process.env.SMTP_FROM_NAME || 'Data Leak Tracker'}" <${process.env.SMTP_FROM_EMAIL || 'noreply@dataleaktracker.com'}>`,
          to: toEmail,
          subject,
          text: bodyText,
          html: bodyHtml
        });
        console.log(`[SMTP Deliver] Real message sent to SMTP host with code ${otpCode} for ${toEmail}`);
      } catch (smtpError) {
        console.error(`[SMTP Deliver Failed] Could not transmit via host ${process.env.SMTP_HOST}. Saved in sandbox Mail Catcher instead.`);
      }
    } else {
      console.log(`[Developer Simulator] Internal core logged secure OTP code "${otpCode}" to mock inbox.`);
    }
  }

  // Developer Tool API: fetch simulated mailbox list for local sandbox UI
  app.get("/api/auth/mail-catcher", (req, res) => {
    return res.json({ emails: mailCatcherLogs });
  });

  // API Route: POST /api/auth/signup
  app.post("/api/auth/signup", async (req, res) => {
    const { name, email, password, confirmPassword } = req.body;

    // Direct Input Presence
    if (!name || !email || !password || !confirmPassword) {
      return res.status(400).json({ 
        message: "Validation Error: All signup fields are strictly required." 
      });
    }

    // Email pattern validation 
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        message: "Validation Error: Please supply a genuine email structure (e.g. name@domain.com)." 
      });
    }

    // Passwords Match Check
    if (password !== confirmPassword) {
      return res.status(400).json({ 
        message: "Validation Error: The entered password and confirmation password do not match." 
      });
    }

    // Password strength enforcement check
    const strength = checkPasswordStrength(password);
    if (!strength.isValid) {
      return res.status(400).json({ 
        message: "Policy Error: Selected password is too weak.",
        failedRules: strength.feedback
      });
    }

    // Check account existence
    if (USERS_DB.has(email.toLowerCase())) {
      return res.status(409).json({ 
        message: "Account conflict: An account matching this email address is already registered." 
      });
    }

    // Generate Verification OTP Code
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString(); // 6 digit code

    // Create New Pending User
    const newUser = {
      id: Date.now(),
      name,
      email: email.toLowerCase(),
      passwordHash: hashString(password),
      verified: false,
      failedLoginAttempts: 0,
      lockoutUntil: null,
      otpRequests: [{ timestamp: Date.now() }],
      otpHash: hashString(otpCode),
      otpPurpose: 'signup' as const,
      otpExpiry: Date.now() + 5 * 60 * 1000, // 5 min
      otpAttempts: 0
    };

    USERS_DB.set(email.toLowerCase(), newUser);

    // Send the OTP Code
    await triggerOtpEmail(email.toLowerCase(), otpCode, `New Operator Account Signup Verification for ${name}`);

    return res.status(201).json({
      message: "Account registered successfully! Please finalize registration by inputting the verification OTP key sent to your inbox.",
      email: email.toLowerCase()
    });
  });

  // API Route: POST /api/auth/login
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ 
        message: "Access Error: Email and password credentials are required." 
      });
    }

    const userKey = email.toLowerCase();
    const user = USERS_DB.get(userKey);

    // If unregistered email
    if (!user) {
      return res.status(401).json({ 
        message: "Authentication failed: Selected email is not currently registered on this console." 
      });
    }

    // Check Brute-force credentials Lockout status
    if (user.lockoutUntil && user.lockoutUntil > Date.now()) {
      const remainingSeconds = Math.ceil((user.lockoutUntil - Date.now()) / 1000);
      return res.status(403).json({
        message: `Brute-force lockout active. This console node is locked due to consecutive errors. Try again in ${remainingSeconds} seconds.`
      });
    }

    // Check password hash match
    const hashedAttempt = hashString(password);
    if (user.passwordHash !== hashedAttempt) {
      user.failedLoginAttempts += 1;
      
      // Limit to 5 failed logins
      if (user.failedLoginAttempts >= 5) {
        user.lockoutUntil = Date.now() + 15 * 60 * 1000; // 15 mins
        return res.status(403).json({
          message: "Corporate Alert: Too many failed auth events. Lockout active. Account is restricted for 15 minutes."
        });
      }

      return res.status(401).json({
        message: `Incorrect credentials. Authentication rejected (Attempt ${user.failedLoginAttempts} of 5 before lockout).`
      });
    }

    // Reset failed count on successful password trigger
    user.failedLoginAttempts = 0;
    user.lockoutUntil = null;

    // Check email verification status
    if (!user.verified) {
      // User created but not verified through signup OTP. Send new OTP code.
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      user.otpRequests.push({ timestamp: Date.now() });
      user.otpHash = hashString(otpCode);
      user.otpPurpose = 'signup';
      user.otpExpiry = Date.now() + 5 * 60 * 1000;
      user.otpAttempts = 0;

      await triggerOtpEmail(user.email, otpCode, `Verify your signup state`);

      return res.status(403).json({
        requiresValidation: true,
        email: user.email,
        purpose: 'signup',
        message: "Your profile is registered but not yet verified. A verification code was transmitted to complete verification."
      });
    }

    // Verified! Initiate multi-factor 2FA Login verify step as requested
    const otpCode2FA = Math.floor(100000 + Math.random() * 900000).toString();
    user.otpRequests.push({ timestamp: Date.now() });
    user.otpHash = hashString(otpCode2FA);
    user.otpPurpose = 'login_2fa';
    user.otpExpiry = Date.now() + 5 * 60 * 1000;
    user.otpAttempts = 0;

    await triggerOtpEmail(user.email, otpCode2FA, "Two-Factor Authentication (2FA) Security Handshake");

    return res.json({
      requiresValidation: true,
      email: user.email,
      purpose: 'login_2fa',
      message: "Credentials accepted. Verification code dispatched. Enter the OTP code to verify your session."
    });
  });

  // API Route: POST /api/auth/verify-otp
  app.post("/api/auth/verify-otp", (req, res) => {
    const { email, otp, purpose } = req.body;

    if (!email || !otp || !purpose) {
      return res.status(400).json({ 
        message: "Missing variables: Provide email, OTP code, and action purpose." 
      });
    }

    const user = USERS_DB.get(email.toLowerCase());
    if (!user) {
      return res.status(404).json({ message: "Operation failed: corporate profile not found." });
    }

    // Validate if OTP exists
    if (!user.otpHash || !user.otpExpiry || user.otpPurpose !== purpose) {
      return res.status(400).json({ 
        message: "Validation failed: No active validation request fits this specification." 
      });
    }

    // Handle check attempts lockout
    user.otpAttempts += 1;
    if (user.otpAttempts > 5) {
      // Invalidate the OTP on 5 attempts
      user.otpHash = null;
      user.otpExpiry = null;
      user.otpPurpose = null;
      user.otpAttempts = 0;
      return res.status(400).json({
        message: "Security Notice: Maximum validation attempts (5) exceeded. This OTP token was invalidated."
      });
    }

    // Check expiry
    if (Date.now() > user.otpExpiry) {
      return res.status(400).json({ 
        message: "Verification failed: OTP code has expired. OTP remains valid for 5 minutes only." 
      });
    }

    // Check OTP hash matching
    const testHash = hashString(otp);
    if (user.otpHash !== testHash) {
      return res.status(400).json({ 
        message: `Invalid code. Attempt ${user.otpAttempts} of 5 inputs before token invalidation.` 
      });
    }

    // MATCHED! Invalidate OTP immediately to prevent reuse as requested
    user.otpHash = null;
    user.otpExpiry = null;
    user.otpPurpose = null;
    user.otpAttempts = 0;

    // Resolve based on purpose
    if (purpose === 'signup') {
      user.verified = true;
      const token = generateJWT({ id: user.id, email: user.email, name: user.name });
      return res.json({
        message: "MFA verified. Pre-verification succeeded. Session established.",
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email
        }
      });
    } else if (purpose === 'login_2fa') {
      const token = generateJWT({ id: user.id, email: user.email, name: user.name });
      return res.json({
        message: "Two-Factor handshake completed. Secure session established.",
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email
        }
      });
    } else if (purpose === 'forgot_password') {
      // Create temporary reset permit key
      const resetPermitToken = "permit_" + crypto.randomBytes(16).toString("hex");
      // Save temp permit on user's active node
      (user as any).resetPermitToken = resetPermitToken;

      return res.json({
        message: "OTP validation check passed. Password resetting authorized.",
        resetPermitToken
      });
    }

    return res.status(400).json({ message: "Failed: ambiguous validation purpose instruction." });
  });

  // API Route: POST /api/auth/resend-otp
  app.post("/api/auth/resend-otp", async (req, res) => {
    const { email, purpose } = req.body;

    if (!email || !purpose) {
      return res.status(400).json({ message: "Invalid requests parameters." });
    }

    const user = USERS_DB.get(email.toLowerCase());
    if (!user) {
      return res.status(404).json({ message: "No registered operator claims this identity." });
    }

    // Enforce OTP quota limits
    const now = Date.now();
    const requests5m = user.otpRequests.filter(r => now - r.timestamp < 5 * 60 * 1000);
    const requests1h = user.otpRequests.filter(r => now - r.timestamp < 60 * 60 * 1000);

    // Filter old entries to prevent infinite memory usage
    user.otpRequests = user.otpRequests.filter(r => now - r.timestamp < 60 * 60 * 1000);

    if (requests5m.length >= 3) {
      return res.status(429).json({
        message: "Rate limit: Maximum of 3 OTP requests allowed every 5 minutes per user. Wait and retry."
      });
    }

    if (requests1h.length >= 10) {
      return res.status(429).json({
        message: "Rate limit: Maximum of 10 OTP requests allowed per hour. Access locked."
      });
    }

    // Safe! Generate new OTP
    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Log request
    user.otpRequests.push({ timestamp: now });
    user.otpHash = hashString(newOtp);
    user.otpPurpose = purpose;
    user.otpExpiry = now + 5 * 60 * 1000;
    user.otpAttempts = 0;

    await triggerOtpEmail(user.email, newOtp, `Resend request: ${purpose}`);

    return res.json({
      message: "A fresh OTP authentication key was transmitted successfully.",
      cooldown: 60 // 1 minute client cooldown feedback hint
    });
  });

  // API Route: POST /api/auth/forgot-password
  app.post("/api/auth/forgot-password", async (req, res) => {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: "Email parameter is required." });
    }

    const user = USERS_DB.get(email.toLowerCase());
    if (!user) {
      // To prevent account enumeration attacks we could return mock success but user expects clear response:
      return res.status(404).json({ 
        message: "This email is not associated with any registered account on our server." 
      });
    }

    // OTP Rate limiting
    const now = Date.now();
    const requests5m = user.otpRequests.filter(r => now - r.timestamp < 5 * 60 * 1000);
    if (requests5m.length >= 3) {
      return res.status(429).json({ message: "Maximum of 3 OTP resets per 5 minutes. Try again later." });
    }

    // Generate forgot password OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    user.otpRequests.push({ timestamp: now });
    user.otpHash = hashString(otpCode);
    user.otpPurpose = 'forgot_password';
    user.otpExpiry = now + 5 * 60 * 1000;
    user.otpAttempts = 0;

    await triggerOtpEmail(user.email, otpCode, "Forgotten Credentials Reset Handshake Code");

    return res.json({
      message: "Reset OTP key transmitted. Supply code to authorize security change.",
      email: user.email
    });
  });

  // API Route: POST /api/auth/reset-password
  app.post("/api/auth/reset-password", (req, res) => {
    const { email, resetPermitToken, newPassword, confirmPassword } = req.body;

    if (!email || !resetPermitToken || !newPassword || !confirmPassword) {
      return res.status(400).json({ 
        message: "Missing parameters: Ensure passwords and validation indicators are complete." 
      });
    }

    const user = USERS_DB.get(email.toLowerCase());
    if (!user) {
      return res.status(404).json({ message: "Target profile not identified." });
    }

    // Validate Reset token match
    if (!(user as any).resetPermitToken || (user as any).resetPermitToken !== resetPermitToken) {
      return res.status(403).json({ 
        message: "Security Permit Expired: Reset permission validation invalid. Restart forgot password flow." 
      });
    }

    // Validate structure equivalence
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ message: "Password mismatch: Entry matches do not reconcile." });
    }

    // Audit password score
    const scoreVal = checkPasswordStrength(newPassword);
    if (!scoreVal.isValid) {
      return res.status(400).json({ 
        message: "Weak Password Reset Blocked: Password failed corporate security policies.",
        failedRules: scoreVal.feedback
      });
    }

    // Safe to rewrite!
    user.passwordHash = hashString(newPassword);
    delete (user as any).resetPermitToken; // remove single use permit
    user.failedLoginAttempts = 0; // unlock account failed limits
    user.lockoutUntil = null;

    return res.json({
      message: "Success! Your password was successfully changed. You can now authenticate."
    });
  });

  // API Route: GET /api/auth/me (Verify JWT validity / fetch current session)
  app.get("/api/auth/me", (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized access: session token missing." });
    }

    const token = authHeader.split(" ")[1];
    const decoded = verifyJWT(token);

    if (!decoded) {
      return res.status(401).json({ error: "Session token expired or has been corrupted." });
    }

    return res.json({
      user: {
        id: decoded.id,
        name: decoded.name,
        email: decoded.email,
        role: "admin",
        verified: true
      }
    });
  });

  // Vite development middleware vs Static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Pattern Engine Server] Fullstack secure container running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Critical server bootstrap disruption: ", err);
});
