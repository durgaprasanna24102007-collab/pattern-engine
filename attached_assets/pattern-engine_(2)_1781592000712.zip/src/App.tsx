import { useState, useEffect } from 'react';
import { 
  INITIAL_PATTERNS, 
  INITIAL_ALERTS, 
  INITIAL_SCANS, 
  INITIAL_LOGS 
} from './defaultData';
import { 
  Pattern, 
  SecurityAlert, 
  ScanTask, 
  ActivityLog, 
  ViewType 
} from './types';
import Navbar from './components/Navbar';
import DashboardView from './components/DashboardView';
import PatternsView from './components/PatternsView';
import ScannerView from './components/ScannerView';
import AlertsView from './components/AlertsView';
import LogsView from './components/LogsView';
import LoginView from './components/LoginView';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('Dashboard');
  const [patterns, setPatterns] = useState<Pattern[]>(INITIAL_PATTERNS);
  const [alerts, setAlerts] = useState<SecurityAlert[]>(INITIAL_ALERTS);
  const [scans, setScans] = useState<ScanTask[]>(INITIAL_SCANS);
  const [logs, setLogs] = useState<ActivityLog[]>(INITIAL_LOGS);
  const [filesScannedCount, setFilesScannedCount] = useState<number>(1248);

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [currentUser, setCurrentUser] = useState<{name: string; email: string} | null>({
    name: "Cyber Security Lead",
    email: "operator@dataleaktracker.com"
  });

  const handleLoginSuccess = (token: string, user: { name: string; email: string }) => {
    setIsAuthenticated(true);
    setCurrentUser(user);
    addLog('success', `Security authentication verified on active terminal`, `Welcome user ${user.name} (${user.email}). Secure session established.`);
  };

  const handleLogout = () => {
    // Session logout stubbed or no-op since login is removed
    addLog('info', 'Secure Logout (Stubbed)', 'Login features have been removed from this system.');
  };

  // Velocity and health stats
  const [velocity] = useState('3.2k');
  const [health] = useState('99.9%');

  // Unified logger helper
  const addLog = (level: ActivityLog['level'], message: string, details?: string) => {
    const time = new Date();
    const timestamp = time.toTimeString().split(' ')[0]; // HH:MM:SS
    const newLog: ActivityLog = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp,
      level,
      message,
      details
    };
    setLogs(prev => [newLog, ...prev]);
  };

  // Toggle rule scanner status
  const handleTogglePattern = (id: string) => {
    setPatterns(prev => prev.map(pat => {
      if (pat.id === id) {
        const nextState = !pat.enabled;
        addLog(
          'info', 
          `${nextState ? 'Enabled' : 'Disabled'} pattern scan validation: "${pat.name}"`, 
          `Rule expression state mutated in memory registry.`
        );
        return { ...pat, enabled: nextState };
      }
      return pat;
    }));
  };

  // Add custom regex signature pattern
  const handleAddPattern = (newPattern: Omit<Pattern, 'id' | 'enabled'>) => {
    const patternId = `pat-${Date.now()}`;
    const generated: Pattern = {
      ...newPattern,
      id: patternId,
      enabled: true
    };
    setPatterns(prev => [...prev, generated]);
    addLog(
      'success', 
      `Successfully registered custom signature rule: "${generated.name}"`, 
      `Compiled safe regular expression string: /${generated.regexStr}/`
    );
  };

  // Acknowledge unresolved security alert
  const handleAcknowledgeAlert = (id: string) => {
    setAlerts(prev => prev.map(alert => {
      if (alert.id === id) {
        addLog(
          'success', 
          `Remediated anomaly alert on file: "${alert.fileName}"`, 
          `Acknowledged and muted pattern trigger match: "${alert.patternName}"`
        );
        return { ...alert, status: 'Acknowledged' as const };
      }
      return alert;
    }));
  };

  // Delete incident log alert record
  const handleDeleteAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => {
      if (alert.id === id) {
        addLog('warning', `Purged anomaly alert incident record on file: "${alert.fileName}"`);
        return false;
      }
      return true;
    }));
  };

  // Cancel simulated active/pending scan tasks
  const handleCancelScan = (id: string) => {
    setScans(prev => prev.map(s => {
      if (s.id === id) {
        addLog('warning', `Canceled active telemetry scan action: "${s.fileName}"`, 'Scan process terminated by safety administrator.');
        return {
          ...s,
          status: 'canceled' as const,
          timeRemaining: 'Canceled by Administrator'
        };
      }
      return s;
    }));
  };

  // Simulated drag-and-drop / manual playbook files hot scanning engine
  const handleTriggerFileScan = (
    fileName: string, 
    size: string, 
    resultsCount: number, 
    detectedAlerts: Omit<SecurityAlert, 'id' | 'timestamp'>[]
  ) => {
    const scanId = `scan-${Date.now()}`;
    const newTask: ScanTask = {
      id: scanId,
      fileName,
      progress: 5,
      status: 'ongoing',
      threatsFound: 0,
      size,
      timeRemaining: 'Estimating...'
    };

    setScans(prev => [newTask, ...prev]);
    addLog('info', `Queued file validation scheduler transaction: "${fileName}" (${size})`);

    let currentPct = 5;
    const trackingInterval = setInterval(() => {
      currentPct += Math.floor(Math.random() * 25) + 12;
      
      if (currentPct >= 100) {
        currentPct = 100;
        clearInterval(trackingInterval);
        
        setScans(prev => prev.map(s => {
          if (s.id === scanId) {
            const finalStatus = resultsCount > 0 ? 'alert' as const : 'done' as const;
            return {
              ...s,
              progress: 100,
              status: finalStatus,
              threatsFound: resultsCount,
              timeRemaining: 'Scan completed.'
            };
          }
          return s;
        }));

        // Add matching findings to alert roster
        if (resultsCount > 0) {
          const timestamp = 'Just now';
          const newAlerts = detectedAlerts.map((tpl, i) => ({
            ...tpl,
            id: `alert-${Date.now()}-${i}`,
            timestamp
          }));
          setAlerts(prev => [...newAlerts, ...prev]);
          addLog(
            'error', 
            `Telemetry warning: Identified ${resultsCount} threat signatures inside "${fileName}"!`, 
            `Discovered matching pattern violations: ${detectedAlerts.map(a => a.patternName).join(', ')}`
          );
        } else {
          addLog(
            'success', 
            `Completed security scan on "${fileName}": Node clean`, 
            'Checked against all active system signature groups. Zero security violations identified.'
          );
        }

        setFilesScannedCount(prev => prev + 1);
      } else {
        // Increment progress incrementally
        setScans(prev => prev.map(s => {
          if (s.id === scanId) {
            return {
              ...s,
              progress: currentPct,
              threatsFound: Math.floor((resultsCount * currentPct) / 100),
              timeRemaining: `Processing... eta ${Math.max(1, Math.ceil((100 - currentPct)/18))}s`
            };
          }
          return s;
        }));
      }
    }, 450);
  };

  // Instant parsed scanning updates over past raw code text
  const handleQuickPasteScan = (findingsCount: number, alertsList: Omit<SecurityAlert, 'id' | 'timestamp'>[]) => {
    setFilesScannedCount(p => p + 1);
    if (findingsCount > 0) {
      const timestamp = 'Just now';
      const newAlerts = alertsList.map((tpl, i) => ({
        ...tpl,
        id: `alert-${Date.now()}-${i}`,
        timestamp
      }));
      setAlerts(prev => [...newAlerts, ...prev]);
    }
  };

  // Clear logs completely
  const handleClearLogs = () => {
    setLogs([]);
    addLog('success', 'Cleared active console logs and trace buffers.', 'Trace histories cleared from session RAM.');
  };

  // Navigation rendering mapping
  const renderActiveView = () => {
    switch (currentView) {
      case 'Dashboard':
        return (
          <DashboardView 
            filesScannedCount={filesScannedCount}
            alerts={alerts}
            patterns={patterns}
            logs={logs}
            onViewChange={setCurrentView}
          />
        );
      case 'Patterns':
        return (
          <PatternsView 
            patterns={patterns}
            onTogglePattern={handleTogglePattern}
            onAddPattern={handleAddPattern}
            velocity={velocity}
            health={health}
          />
        );
      case 'Scanner':
        return (
          <ScannerView 
            patterns={patterns}
            scans={scans}
            onTriggerScan={handleTriggerFileScan}
            onQuickPasteScan={handleQuickPasteScan}
            onAddLog={addLog}
            onCancelScan={handleCancelScan}
          />
        );
      case 'Alerts':
        return (
          <AlertsView 
            alerts={alerts}
            onAcknowledgeAlert={handleAcknowledgeAlert}
            onDeleteAlert={handleDeleteAlert}
          />
        );
      case 'Logs':
        return (
          <LogsView 
            logs={logs}
            onClearLogs={handleClearLogs}
            onAddLog={addLog}
          />
        );
      default:
        return (
          <DashboardView 
            filesScannedCount={filesScannedCount}
            alerts={alerts}
            patterns={patterns}
            logs={logs}
            onViewChange={setCurrentView}
          />
        );
    }
  };

  // Active unresolved alert tracks for state header pill alerts
  const unresolvedAlertsCount = alerts.filter(a => a.status === 'Unresolved').length;

  // Removed login check to allow instant direct terminal access.

  return (
    <div className="min-h-screen bg-background text-on-surface select-none pb-20">
      
      {/* Top and Bottom responsive Navigation */}
      <Navbar 
        currentView={currentView}
        onViewChange={setCurrentView}
        unresolvedAlertsCount={unresolvedAlertsCount}
        userName={currentUser?.name}
      />

      {/* Main Container screen content wrapper */}
      <main id="main-scroll" className="pt-20 px-6 max-w-5xl mx-auto pb-10">
        <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
          {renderActiveView()}
        </div>
      </main>
      
    </div>
  );
}
