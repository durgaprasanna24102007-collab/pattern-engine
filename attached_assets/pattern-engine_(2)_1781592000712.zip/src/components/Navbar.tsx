import { 
  Shield, 
  Bell, 
  LayoutDashboard, 
  Braces, 
  Scan, 
  AlertTriangle, 
  History
} from 'lucide-react';
import { ViewType } from '../types';

interface NavbarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
  unresolvedAlertsCount: number;
  userName?: string;
}

export default function Navbar({ 
  currentView, 
  onViewChange, 
  unresolvedAlertsCount,
  userName
}: NavbarProps) {
  
  // Dynamic Title based on Active Screen
  const getTitle = () => {
    switch (currentView) {
      case 'Dashboard':
        return 'Data Leak Tracker';
      case 'Patterns':
        return 'Pattern Engine';
      case 'Scanner':
        return 'DLP Scanner';
      case 'Alerts':
        return 'Security Alerts';
      case 'Logs':
        return 'System Logs';
      default:
        return 'Pattern Engine';
    }
  };

  return (
    <>
      {/* TopAppBar */}
      <header className="fixed top-0 left-0 w-full z-45 bg-amber-50/5 bg-opacity-95 backdrop-blur-md bg-white border-b border-outline-variant flex justify-between items-center px-6 h-16 shadow-xs">
        <div className="flex items-center gap-3">
          <Shield className="h-6 w-6 text-primary" strokeWidth={2.5} />
          <h1 className="text-lg font-bold text-primary tracking-tight font-sans">
            {getTitle()}
          </h1>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onViewChange('Alerts')}
            className="p-2 rounded-full hover:bg-surface-container-high transition-all active:scale-95 text-on-surface-variant relative cursor-pointer"
            title="View Alerts"
          >
            <Bell className="h-5 w-5" />
            {unresolvedAlertsCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-error text-white font-sans text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {unresolvedAlertsCount}
              </span>
            )}
          </button>
          
          <div className="hidden sm:flex flex-col text-right pr-2">
            <span className="text-xs font-bold text-primary font-sans">{userName || 'Admin User'}</span>
            <span className="text-[10px] text-green-600 font-mono font-bold">● ONLINE</span>
          </div>
        </div>
      </header>

      {/* BottomNavBar */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center h-20 px-2 pb-safe bg-white border-t border-outline-variant shadow-lg" id="bottom-bar">
        {/* Dashboard */}
        <button
          onClick={() => onViewChange('Dashboard')}
          className={`flex flex-col items-center justify-center h-14 w-18 rounded-xl transition-all cursor-pointer ${
            currentView === 'Dashboard'
              ? 'bg-primary-fixed text-on-primary-fixed bg-blue-100 font-bold scale-105'
              : 'text-on-surface-variant hover:text-primary hover:bg-surface-container-low'
          }`}
        >
          <LayoutDashboard className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1 font-sans">Dashboard</span>
        </button>

        {/* Patterns */}
        <button
          onClick={() => onViewChange('Patterns')}
          className={`flex flex-col items-center justify-center h-14 w-18 rounded-xl transition-all cursor-pointer ${
            currentView === 'Patterns'
              ? 'bg-primary-fixed text-on-primary-fixed bg-blue-100 font-bold scale-105'
              : 'text-on-surface-variant hover:text-primary hover:bg-surface-container-low'
          }`}
        >
          <Braces className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1 font-sans">Patterns</span>
        </button>

        {/* Scanner */}
        <button
          onClick={() => onViewChange('Scanner')}
          className={`flex flex-col items-center justify-center h-14 w-18 rounded-xl transition-all cursor-pointer ${
            currentView === 'Scanner'
              ? 'bg-primary-fixed text-on-primary-fixed bg-blue-100 font-bold scale-105'
              : 'text-on-surface-variant hover:text-primary hover:bg-surface-container-low'
          }`}
        >
          <Scan className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1 font-sans">Scanner</span>
        </button>

        {/* Alerts */}
        <button
          onClick={() => onViewChange('Alerts')}
          className={`flex flex-col items-center justify-center h-14 w-18 rounded-xl transition-all cursor-pointer relative ${
            currentView === 'Alerts'
              ? 'bg-primary-fixed text-on-primary-fixed bg-blue-100 font-bold scale-105'
              : 'text-on-surface-variant hover:text-primary hover:bg-surface-container-low'
          }`}
        >
          <AlertTriangle className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1 font-sans">Alerts</span>
          {unresolvedAlertsCount > 0 && (
            <span className="absolute top-2 right-4 w-2 h-2 bg-error rounded-full" />
          )}
        </button>

        {/* Logs */}
        <button
          onClick={() => onViewChange('Logs')}
          className={`flex flex-col items-center justify-center h-14 w-18 rounded-xl transition-all cursor-pointer ${
            currentView === 'Logs'
              ? 'bg-primary-fixed text-on-primary-fixed bg-blue-100 font-bold scale-105'
              : 'text-on-surface-variant hover:text-primary hover:bg-surface-container-low'
          }`}
        >
          <History className="h-5 w-5" />
          <span className="text-[10px] font-medium mt-1 font-sans">Logs</span>
        </button>
      </nav>
    </>
  );
}
